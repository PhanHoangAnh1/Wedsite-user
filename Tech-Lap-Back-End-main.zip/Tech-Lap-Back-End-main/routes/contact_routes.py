from flask import request, jsonify
from flask_restx import Namespace, Resource, fields
from database import contact_messages_collection
from models.contact import ContactMessage
from bson import ObjectId
from datetime import datetime, timedelta
import uuid
from utils.mongo_utils import serialize_to_json

# Create a namespace for contact form API
contact_ns = Namespace('contact', description='Contact form operations')

# Define contact message model for swagger documentation
contact_model = contact_ns.model('Contact', {
    'name': fields.String(required=True, description='Full name'),
    'email': fields.String(required=True, description='Email address'),
    'phone': fields.String(required=False, description='Phone number'),
    'subject': fields.String(required=True, description='Message subject'),
    'message': fields.String(required=True, description='Message content')
})

# Define response models
success_model = contact_ns.model('SuccessResponse', {
    'success': fields.Boolean(default=True),
    'messageId': fields.String(description='Unique message ID'),
    'message': fields.String(description='Success message')
})

error_model = contact_ns.model('ErrorResponse', {
    'success': fields.Boolean(default=False),
    'error': fields.String(description='Error type'),
    'message': fields.String(description='Error message'),
    'fields': fields.Raw(description='Field validation errors')
})

# Dictionary to track submission rates
rate_limit_tracker = {}

def check_rate_limit(ip_address):
    """
    Check if IP address has exceeded rate limit (5 submissions per hour)
    """
    now = datetime.now()
    one_hour_ago = now - timedelta(hours=1)
    
    # Clean up old entries
    for ip in list(rate_limit_tracker.keys()):
        rate_limit_tracker[ip] = [timestamp for timestamp in rate_limit_tracker[ip] if timestamp > one_hour_ago]
        if not rate_limit_tracker[ip]:
            del rate_limit_tracker[ip]
    
    # Check current IP
    if ip_address not in rate_limit_tracker:
        rate_limit_tracker[ip_address] = []
    
    # Count submissions in the last hour
    submissions = rate_limit_tracker[ip_address]
    if len(submissions) >= 5:
        return False
    
    # Add current submission timestamp
    rate_limit_tracker[ip_address].append(now)
    return True

@contact_ns.route('')
class ContactAPI(Resource):
    @contact_ns.expect(contact_model)
    @contact_ns.response(200, 'Success', success_model)
    @contact_ns.response(400, 'Validation Error', error_model)
    @contact_ns.response(429, 'Rate Limit Exceeded', error_model)
    @contact_ns.response(500, 'Server Error', error_model)
    def post(self):
        """
        Submit a contact form message
        """
        try:
            # Get client IP address
            ip_address = request.remote_addr
            
            # Check rate limit
            if not check_rate_limit(ip_address):
                return {
                    'success': False,
                    'error': 'rate_limit_exceeded',
                    'message': 'Quá nhiều yêu cầu. Vui lòng thử lại sau.'
                }, 429
            
            # Get request data
            data = request.json
            
            # Create and validate contact message
            contact_message = ContactMessage.from_dict(data)
            validation_errors = contact_message.validate()
            
            if validation_errors:
                return {
                    'success': False,
                    'error': 'validation_error',
                    'fields': validation_errors
                }, 400
            
            # Generate a unique message ID
            message_id = str(uuid.uuid4())
            
            # Save to database
            contact_dict = contact_message.to_dict()
            contact_dict['message_id'] = message_id
            contact_messages_collection.insert_one(contact_dict)
            
            # Return success response
            return {
                'success': True,
                'messageId': message_id,
                'message': 'Tin nhắn của bạn đã được gửi thành công'
            }, 200
        
        except Exception as e:
            # Log the error (you can add proper logging here)
            print(f"Error in contact form submission: {str(e)}")
            
            # Return error response
            return {
                'success': False,
                'error': 'server_error',
                'message': 'Đã xảy ra lỗi khi gửi tin nhắn. Vui lòng thử lại sau.'
            }, 500

    @contact_ns.response(200, 'Success')
    @contact_ns.response(500, 'Server Error', error_model)
    def get(self):
        """
        Get all contact form messages
        """
        try:
            # Get query parameters for pagination
            page = int(request.args.get('page', 1))
            limit = int(request.args.get('limit', 10))
            skip = (page - 1) * limit
            
            # Get filter parameters
            status = request.args.get('status')
            search = request.args.get('search')
            
            # Prepare filter query
            query = {}
            if status:
                query['status'] = status
            if search:
                query['$or'] = [
                    {'name': {'$regex': search, '$options': 'i'}},
                    {'email': {'$regex': search, '$options': 'i'}},
                    {'subject': {'$regex': search, '$options': 'i'}}
                ]
            
            # Get total count for pagination
            total_count = contact_messages_collection.count_documents(query)
            
            # Get messages with pagination
            messages = list(contact_messages_collection.find(query).sort('created_at', -1).skip(skip).limit(limit))
            
            # Serialize results
            serialized_messages = serialize_to_json(messages)
            
            # Calculate total pages
            total_pages = (total_count + limit - 1) // limit
            
            return {
                'success': True,
                'data': serialized_messages,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total': total_count,
                    'total_pages': total_pages
                }
            }, 200
            
        except Exception as e:
            print(f"Error retrieving contact messages: {str(e)}")
            return {
                'success': False,
                'error': 'server_error',
                'message': 'Đã xảy ra lỗi khi lấy tin nhắn. Vui lòng thử lại sau.'
            }, 500

@contact_ns.route('/<string:message_id>')
class ContactDetailAPI(Resource):
    @contact_ns.response(200, 'Success')
    @contact_ns.response(404, 'Not Found', error_model)
    @contact_ns.response(500, 'Server Error', error_model)
    def get(self, message_id):
        """
        Get a specific contact message by ID
        """
        try:
            # Try to find by message_id first
            message = contact_messages_collection.find_one({'message_id': message_id})
            
            # If not found, try to find by ObjectId if valid
            if not message:
                try:
                    if ObjectId.is_valid(message_id):
                        message = contact_messages_collection.find_one({'_id': ObjectId(message_id)})
                except:
                    pass
            
            if not message:
                return {
                    'success': False,
                    'error': 'not_found',
                    'message': 'Không tìm thấy tin nhắn'
                }, 404
            
            # Update status to read if it was unread
            if message.get('status') == 'unread':
                contact_messages_collection.update_one(
                    {'_id': message['_id']},
                    {'$set': {'status': 'read'}}
                )
                message['status'] = 'read'
            
            return {
                'success': True,
                'data': serialize_to_json(message)
            }, 200
            
        except Exception as e:
            print(f"Error retrieving contact message: {str(e)}")
            return {
                'success': False,
                'error': 'server_error',
                'message': 'Đã xảy ra lỗi khi lấy tin nhắn. Vui lòng thử lại sau.'
            }, 500

    @contact_ns.response(200, 'Success')
    @contact_ns.response(404, 'Not Found', error_model)
    @contact_ns.response(500, 'Server Error', error_model)
    def delete(self, message_id):
        """
        Delete a specific contact message
        """
        try:
            # Try to find by message_id first
            query = {'message_id': message_id}
            
            # If not found, try to find by ObjectId if valid
            message = contact_messages_collection.find_one(query)
            if not message and ObjectId.is_valid(message_id):
                query = {'_id': ObjectId(message_id)}
                message = contact_messages_collection.find_one(query)
            
            if not message:
                return {
                    'success': False,
                    'error': 'not_found',
                    'message': 'Không tìm thấy tin nhắn'
                }, 404
            
            # Delete the message
            contact_messages_collection.delete_one(query)
            
            return {
                'success': True,
                'message': 'Tin nhắn đã được xóa thành công'
            }, 200
            
        except Exception as e:
            print(f"Error deleting contact message: {str(e)}")
            return {
                'success': False,
                'error': 'server_error',
                'message': 'Đã xảy ra lỗi khi xóa tin nhắn. Vui lòng thử lại sau.'
            }, 500 
from flask import request
from flask_restx import Namespace, Resource, fields, reqparse
from database import products_collection, orders_collection
from bson import ObjectId
from datetime import datetime, timedelta
from utils.mongo_utils import object_id_to_str
import calendar

# Create namespace for product statistics operations
product_statistics_ns = Namespace('product-statistics', description='Product statistics and reporting operations')

# Parser for query parameters
period_parser = reqparse.RequestParser()
period_parser.add_argument('period', type=str, choices=('daily', 'weekly', 'monthly', 'yearly', 'custom'), 
                         default='monthly', help='Time period for product statistics')
period_parser.add_argument('start_date', type=str, help='Start date for custom period (YYYY-MM-DD)')
period_parser.add_argument('end_date', type=str, help='End date for custom period (YYYY-MM-DD)')
period_parser.add_argument('year', type=int, help='Year for yearly statistics')
period_parser.add_argument('month', type=int, help='Month for monthly statistics')
period_parser.add_argument('limit', type=int, default=10, help='Limit number of results')
period_parser.add_argument('category_id', type=str, help='Filter by category ID')

# Response models
product_stat_model = product_statistics_ns.model('ProductStat', {
    'product_id': fields.String(description='Product ID'),
    'name': fields.String(description='Product name'),
    'brand': fields.String(description='Product brand'),
    'total_sales': fields.Integer(description='Total sales count'),
    'total_revenue': fields.Float(description='Total revenue'),
    'current_stock': fields.Integer(description='Current stock level')
})

category_stat_model = product_statistics_ns.model('CategoryStat', {
    'category_id': fields.String(description='Category ID'),
    'name': fields.String(description='Category name'),
    'total_products': fields.Integer(description='Total products in category'),
    'total_sales': fields.Integer(description='Total sales count'),
    'total_revenue': fields.Float(description='Total revenue')
})

inventory_stat_model = product_statistics_ns.model('InventoryStat', {
    'total_products': fields.Integer(description='Total product count'),
    'total_value': fields.Float(description='Total inventory value'),
    'low_stock_count': fields.Integer(description='Number of products with low stock'),
    'out_of_stock_count': fields.Integer(description='Number of products out of stock')
})

stats_response_model = product_statistics_ns.model('StatsResponse', {
    'success': fields.Boolean(description='Success status'),
    'message': fields.String(description='Response message'),
    'data': fields.Raw(description='Statistics data')
})

@product_statistics_ns.route('/top-selling')
class TopSellingProducts(Resource):
    @product_statistics_ns.doc('get_top_selling_products')
    @product_statistics_ns.expect(period_parser)
    @product_statistics_ns.response(200, 'Success', stats_response_model)
    def get(self):
        """Get top selling products for specified period"""
        args = period_parser.parse_args()
        period = args.get('period', 'monthly')
        limit = args.get('limit', 10)
        category_id = args.get('category_id')
        
        # Determine date range based on period
        start_date, end_date = get_date_range(args)
        
        # Build match pipeline
        match_pipeline = {
            'order_date': {'$gte': start_date, '$lte': end_date}
        }
        
        # Prepare aggregation pipeline
        pipeline = [
            {'$match': match_pipeline},
            {'$unwind': '$items'},
            {'$group': {
                '_id': '$items.product_id',
                'total_quantity': {'$sum': '$items.quantity'},
                'total_revenue': {'$sum': {'$multiply': ['$items.quantity', '$items.price']}}
            }},
            {'$sort': {'total_quantity': -1}},
            {'$limit': limit}
        ]
        
        # Execute aggregation
        top_products_data = list(orders_collection.aggregate(pipeline))
        
        # Get product details for each product ID
        result = []
        for item in top_products_data:
            product_id = item['_id']
            product = products_collection.find_one({'_id': ObjectId(product_id)})
            
            if product:
                result.append({
                    'product_id': str(product['_id']),
                    'name': product.get('name', 'Unknown'),
                    'brand': product.get('brand', 'Unknown'),
                    'total_sales': int(item['total_quantity']),
                    'total_revenue': float(item['total_revenue']),
                    'current_stock': int(product.get('stock_quantity', 0))
                })
        
        return {
            'success': True,
            'message': f'Top selling products for {period} period',
            'data': result
        }

@product_statistics_ns.route('/by-category')
class ProductsByCategory(Resource):
    @product_statistics_ns.doc('get_products_by_category')
    @product_statistics_ns.expect(period_parser)
    @product_statistics_ns.response(200, 'Success', stats_response_model)
    def get(self):
        """Get product statistics grouped by category"""
        args = period_parser.parse_args()
        period = args.get('period', 'monthly')
        
        # Determine date range based on period
        start_date, end_date = get_date_range(args)
        
        # Build match pipeline for orders
        match_pipeline = {
            'order_date': {'$gte': start_date, '$lte': end_date}
        }
        
        # Get sales data per product
        sales_pipeline = [
            {'$match': match_pipeline},
            {'$unwind': '$items'},
            {'$group': {
                '_id': '$items.product_id',
                'total_quantity': {'$sum': '$items.quantity'},
                'total_revenue': {'$sum': {'$multiply': ['$items.quantity', '$items.price']}}
            }}
        ]
        
        sales_data = {str(item['_id']): {
            'total_quantity': item['total_quantity'],
            'total_revenue': item['total_revenue']
        } for item in orders_collection.aggregate(sales_pipeline)}
        
        # Get all products with their categories
        products = list(products_collection.find({}, {'name': 1, 'category_ids': 1, 'stock_quantity': 1}))
        
        # Group products by category
        category_stats = {}
        for product in products:
            product_id = str(product['_id'])
            product_categories = product.get('category_ids', [])
            
            # Get sales data for this product
            product_sales = sales_data.get(product_id, {'total_quantity': 0, 'total_revenue': 0})
            
            for category_id in product_categories:
                category_id = str(category_id)
                if category_id not in category_stats:
                    category_stats[category_id] = {
                        'total_products': 0,
                        'total_sales': 0,
                        'total_revenue': 0
                    }
                
                category_stats[category_id]['total_products'] += 1
                category_stats[category_id]['total_sales'] += int(product_sales.get('total_quantity', 0))
                category_stats[category_id]['total_revenue'] += float(product_sales.get('total_revenue', 0))
        
        # Get category names
        from database import categories_collection
        result = []
        for category_id, stats in category_stats.items():
            category = categories_collection.find_one({'_id': ObjectId(category_id)})
            category_name = category['name'] if category else 'Unknown Category'
            
            result.append({
                'category_id': category_id,
                'name': category_name,
                'total_products': stats['total_products'],
                'total_sales': stats['total_sales'],
                'total_revenue': stats['total_revenue']
            })
        
        # Sort by total sales
        result.sort(key=lambda x: x['total_sales'], reverse=True)
        
        return {
            'success': True,
            'message': f'Product statistics by category for {period} period',
            'data': result
        }

@product_statistics_ns.route('/inventory-status')
class InventoryStatus(Resource):
    @product_statistics_ns.doc('get_inventory_status')
    @product_statistics_ns.response(200, 'Success', stats_response_model)
    def get(self):
        """Get current inventory status and statistics"""
        # Get all products
        products = list(products_collection.find({}, {
            'name': 1, 'brand': 1, 'price': 1, 'stock_quantity': 1, 'status': 1
        }))
        
        # Calculate overall stats
        total_products = len(products)
        total_value = sum(float(product.get('price', 0)) * int(product.get('stock_quantity', 0)) for product in products)
        low_stock_count = sum(1 for product in products if int(product.get('stock_quantity', 0)) <= 5 and int(product.get('stock_quantity', 0)) > 0)
        out_of_stock_count = sum(1 for product in products if int(product.get('stock_quantity', 0)) == 0 or product.get('status') == 'out_of_stock')
        
        # Prepare summary data
        summary = {
            'total_products': total_products,
            'total_value': total_value,
            'low_stock_count': low_stock_count,
            'out_of_stock_count': out_of_stock_count,
            'in_stock_count': total_products - out_of_stock_count
        }
        
        # Get low stock products
        low_stock_products = [format_product_stats(product) for product in products 
                             if int(product.get('stock_quantity', 0)) <= 5 and int(product.get('stock_quantity', 0)) > 0]
        
        # Get out of stock products
        out_of_stock_products = [format_product_stats(product) for product in products 
                                if int(product.get('stock_quantity', 0)) == 0 or product.get('status') == 'out_of_stock']
        
        return {
            'success': True,
            'message': 'Current inventory status',
            'data': {
                'summary': summary,
                'low_stock_products': low_stock_products,
                'out_of_stock_products': out_of_stock_products
            }
        }

@product_statistics_ns.route('/sales-trends')
class SalesTrends(Resource):
    @product_statistics_ns.doc('get_sales_trends')
    @product_statistics_ns.expect(period_parser)
    @product_statistics_ns.response(200, 'Success', stats_response_model)
    def get(self):
        """Get product sales trends over time"""
        args = period_parser.parse_args()
        period = args.get('period', 'monthly')
        
        # Determine date range and interval format based on period
        start_date, end_date = get_date_range(args)
        
        if period == 'daily':
            group_id = {'$dateToString': {'format': '%Y-%m-%d', 'date': '$order_date'}}
        elif period == 'weekly':
            group_id = {
                'year': {'$year': '$order_date'},
                'week': {'$week': '$order_date'}
            }
        elif period == 'monthly':
            group_id = {
                'year': {'$year': '$order_date'},
                'month': {'$month': '$order_date'}
            }
        else:  # yearly
            group_id = {'$year': '$order_date'}
        
        # Build aggregation pipeline
        pipeline = [
            {'$match': {'order_date': {'$gte': start_date, '$lte': end_date}}},
            {'$unwind': '$items'},
            {'$group': {
                '_id': {
                    'time': group_id,
                    'product_id': '$items.product_id'
                },
                'quantity': {'$sum': '$items.quantity'},
                'revenue': {'$sum': {'$multiply': ['$items.quantity', '$items.price']}}
            }},
            {'$sort': {'_id.time': 1}}
        ]
        
        # Execute aggregation
        trends_data = list(orders_collection.aggregate(pipeline))
        
        # Format result
        result = {}
        for item in trends_data:
            time_key = format_time_key(item['_id']['time'], period)
            product_id = str(item['_id']['product_id'])
            
            if time_key not in result:
                result[time_key] = {}
            
            # Get product info
            if product_id not in result[time_key]:
                product = products_collection.find_one({'_id': ObjectId(product_id)})
                product_name = product['name'] if product else 'Unknown Product'
                
                result[time_key][product_id] = {
                    'product_id': product_id,
                    'name': product_name,
                    'quantity': 0,
                    'revenue': 0
                }
            
            result[time_key][product_id]['quantity'] += int(item['quantity'])
            result[time_key][product_id]['revenue'] += float(item['revenue'])
        
        # Convert to list format
        formatted_result = []
        for time_key, products in result.items():
            formatted_result.append({
                'period': time_key,
                'products': list(products.values())
            })
        
        # Sort by time
        formatted_result.sort(key=lambda x: x['period'])
        
        return {
            'success': True,
            'message': f'Product sales trends for {period} period',
            'data': formatted_result
        }

def get_date_range(args):
    """Helper function to determine date range based on query parameters"""
    period = args.get('period', 'monthly')
    now = datetime.now()
    
    if period == 'custom':
        try:
            start_date = datetime.strptime(args.get('start_date'), '%Y-%m-%d')
            end_date = datetime.strptime(args.get('end_date'), '%Y-%m-%d')
            # Include the entire end date
            end_date = end_date.replace(hour=23, minute=59, second=59)
        except (ValueError, TypeError):
            # Default to last 30 days if invalid dates
            end_date = now
            start_date = now - timedelta(days=30)
    elif period == 'daily':
        start_date = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end_date = now
    elif period == 'weekly':
        start_date = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
        end_date = now
    elif period == 'monthly':
        year = args.get('year', now.year)
        month = args.get('month', now.month)
        
        # Ensure year and month are integers with fallback to current date
        if year is None:
            year = now.year
        if month is None:
            month = now.month
            
        start_date = datetime(year, month, 1)
        # Get last day of month
        if month == 12:
            end_date = datetime(year + 1, 1, 1) - timedelta(days=1)
        else:
            end_date = datetime(year, month + 1, 1) - timedelta(days=1)
        end_date = end_date.replace(hour=23, minute=59, second=59)
    elif period == 'yearly':
        year = args.get('year', now.year)
        # Ensure year is an integer with fallback to current year
        if year is None:
            year = now.year
            
        start_date = datetime(year, 1, 1)
        end_date = datetime(year, 12, 31, 23, 59, 59)
    else:
        # Default to last 30 days
        end_date = now
        start_date = now - timedelta(days=30)
    
    return start_date, end_date

def format_time_key(time_data, period):
    """Format time key for consistent representation"""
    if period == 'daily':
        return time_data
    elif period == 'weekly':
        year = time_data['year']
        week = time_data['week']
        return f"{year}-W{week:02d}"
    elif period == 'monthly':
        year = time_data['year']
        month = time_data['month']
        return f"{year}-{month:02d}"
    else:  # yearly
        return str(time_data)

def format_product_stats(product):
    """Format product data for statistics response"""
    return {
        'product_id': str(product['_id']),
        'name': product.get('name', 'Unknown'),
        'brand': product.get('brand', 'Unknown'),
        'current_stock': product.get('stock_quantity', 0),
        'status': product.get('status', 'unknown')
    } 
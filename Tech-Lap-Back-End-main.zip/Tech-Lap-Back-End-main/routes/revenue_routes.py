from flask import request
from flask_restx import Namespace, Resource, fields, reqparse
from database import orders_collection
from bson import ObjectId
from datetime import datetime, timedelta
from utils.mongo_utils import object_id_to_str
import calendar

# Create namespace for revenue operations
revenue_ns = Namespace('revenue', description='Revenue reporting and statistics operations')

# Parser for query parameters
period_parser = reqparse.RequestParser()
period_parser.add_argument('period', type=str, choices=('daily', 'weekly', 'monthly', 'yearly', 'custom'), 
                         default='monthly', help='Time period for revenue statistics')
period_parser.add_argument('start_date', type=str, help='Start date for custom period (YYYY-MM-DD)')
period_parser.add_argument('end_date', type=str, help='End date for custom period (YYYY-MM-DD)')
period_parser.add_argument('year', type=int, help='Year for yearly statistics')
period_parser.add_argument('month', type=int, help='Month for monthly statistics')

# Response models
revenue_data_model = revenue_ns.model('RevenueData', {
    'period': fields.String(description='Time period label'),
    'total_revenue': fields.Float(description='Total revenue'),
    'total_orders': fields.Integer(description='Total number of orders'),
    'average_order_value': fields.Float(description='Average order value')
})

revenue_response_model = revenue_ns.model('RevenueResponse', {
    'success': fields.Boolean(description='Success status'),
    'message': fields.String(description='Response message'),
    'data': fields.List(fields.Nested(revenue_data_model), description='Revenue data')
})

summary_response_model = revenue_ns.model('RevenueSummary', {
    'success': fields.Boolean(description='Success status'),
    'message': fields.String(description='Response message'),
    'data': fields.Raw(description='Summary data')
})

@revenue_ns.route('/statistics')
class RevenueStatistics(Resource):
    @revenue_ns.doc('get_revenue_statistics')
    @revenue_ns.expect(period_parser)
    @revenue_ns.response(200, 'Success', revenue_response_model)
    def get(self):
        """Get revenue statistics for specified period"""
        args = period_parser.parse_args()
        period = args.get('period', 'monthly')
        
        now = datetime.now()
        
        if period == 'daily':
            # Daily statistics for the last 30 days
            start_date = now - timedelta(days=30)
            end_date = now
            pipeline = [
                {
                    "$match": {
                        "orderDate": {"$gte": start_date, "$lte": end_date},
                        "status": "delivered"
                    }
                },
                {
                    "$group": {
                        "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$orderDate"}},
                        "total_revenue": {"$sum": "$total"},
                        "total_orders": {"$sum": 1}
                    }
                },
                {"$sort": {"_id": 1}}
            ]
            
        elif period == 'weekly':
            # Weekly statistics for the last 12 weeks
            start_date = now - timedelta(weeks=12)
            end_date = now
            pipeline = [
                {
                    "$match": {
                        "orderDate": {"$gte": start_date, "$lte": end_date},
                        "status": "delivered"
                    }
                },
                {
                    "$group": {
                        "_id": {
                            "year": {"$year": "$orderDate"},
                            "week": {"$week": "$orderDate"}
                        },
                        "start_date": {"$min": "$orderDate"},
                        "total_revenue": {"$sum": "$total"},
                        "total_orders": {"$sum": 1}
                    }
                },
                {"$sort": {"_id.year": 1, "_id.week": 1}}
            ]
            
        elif period == 'monthly':
            # Monthly statistics for the last 12 months
            start_date = datetime(now.year - 1, now.month + 1, 1) if now.month < 12 else datetime(now.year, 1, 1)
            end_date = now
            pipeline = [
                {
                    "$match": {
                        "orderDate": {"$gte": start_date, "$lte": end_date},
                        "status": "delivered"
                    }
                },
                {
                    "$group": {
                        "_id": {
                            "year": {"$year": "$orderDate"},
                            "month": {"$month": "$orderDate"}
                        },
                        "total_revenue": {"$sum": "$total"},
                        "total_orders": {"$sum": 1}
                    }
                },
                {"$sort": {"_id.year": 1, "_id.month": 1}}
            ]
            
        elif period == 'yearly':
            # Yearly statistics for the last 5 years
            year = args.get('year')
            if year is None:
                # Default to last 5 years if year not specified
                start_date = datetime(now.year - 5, 1, 1)
                end_date = now
            else:
                start_date = datetime(year, 1, 1)
                end_date = datetime(year, 12, 31)
                
            pipeline = [
                {
                    "$match": {
                        "orderDate": {"$gte": start_date, "$lte": end_date},
                        "status": "delivered"
                    }
                },
                {
                    "$group": {
                        "_id": {"$year": "$orderDate"},
                        "total_revenue": {"$sum": "$total"},
                        "total_orders": {"$sum": 1}
                    }
                },
                {"$sort": {"_id": 1}}
            ]
            
        elif period == 'custom':
            # Custom date range
            try:
                start_date_str = args.get('start_date')
                end_date_str = args.get('end_date')
                
                if not start_date_str or not end_date_str:
                    return {
                        "success": False,
                        "message": "Both start_date and end_date are required for custom period"
                    }, 400
                    
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
                end_date = datetime.combine(end_date.date(), datetime.max.time())  # Set to end of day
                
                pipeline = [
                    {
                        "$match": {
                            "orderDate": {"$gte": start_date, "$lte": end_date},
                            "status": "delivered"
                        }
                    },
                    {
                        "$group": {
                            "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$orderDate"}},
                            "total_revenue": {"$sum": "$total"},
                            "total_orders": {"$sum": 1}
                        }
                    },
                    {"$sort": {"_id": 1}}
                ]
            except ValueError:
                return {
                    "success": False,
                    "message": "Invalid date format. Use YYYY-MM-DD"
                }, 400
        
        # Execute aggregation pipeline
        result = list(orders_collection.aggregate(pipeline))
        
        # Format response data
        response_data = []
        
        for item in result:
            if period == 'monthly':
                year = item['_id']['year']
                month = item['_id']['month']
                month_name = calendar.month_name[month]
                period_label = f"{month_name} {year}"
            elif period == 'weekly':
                year = item['_id']['year']
                week = item['_id']['week']
                period_label = f"Week {week}, {year}"
            elif period == 'yearly':
                period_label = str(item['_id'])
            else:
                period_label = item['_id']
                
            average_order_value = item['total_revenue'] / item['total_orders'] if item['total_orders'] > 0 else 0
            
            response_data.append({
                "period": period_label,
                "total_revenue": item['total_revenue'],
                "total_orders": item['total_orders'],
                "average_order_value": average_order_value
            })
            
        return {
            "success": True,
            "message": f"Revenue statistics for {period} period",
            "data": response_data
        }, 200

@revenue_ns.route('/summary')
class RevenueSummary(Resource):
    @revenue_ns.doc('get_revenue_summary')
    @revenue_ns.response(200, 'Success', summary_response_model)
    def get(self):
        """Get revenue summary with various metrics"""
        now = datetime.now()
        
        # Today's revenue
        today_start = datetime.combine(now.date(), datetime.min.time())
        today_end = datetime.combine(now.date(), datetime.max.time())
        
        # This month's revenue
        month_start = datetime(now.year, now.month, 1)
        if now.month == 12:
            month_end = datetime(now.year + 1, 1, 1) - timedelta(days=1)
        else:
            month_end = datetime(now.year, now.month + 1, 1) - timedelta(days=1)
        month_end = datetime.combine(month_end.date(), datetime.max.time())
        
        # This year's revenue
        year_start = datetime(now.year, 1, 1)
        year_end = datetime(now.year, 12, 31)
        year_end = datetime.combine(year_end.date(), datetime.max.time())
        
        # Previous month for comparison
        if now.month == 1:
            prev_month_start = datetime(now.year - 1, 12, 1)
            prev_month_end = datetime(now.year, 1, 1) - timedelta(days=1)
        else:
            prev_month_start = datetime(now.year, now.month - 1, 1)
            prev_month_end = month_start - timedelta(days=1)
        prev_month_end = datetime.combine(prev_month_end.date(), datetime.max.time())
        
        # Create metrics pipeline
        pipeline = [
            {
                "$facet": {
                    "today": [
                        {
                            "$match": {
                                "orderDate": {"$gte": today_start, "$lte": today_end},
                                "status": "delivered"
                            }
                        },
                        {
                            "$group": {
                                "_id": None,
                                "revenue": {"$sum": "$total"},
                                "orders": {"$sum": 1}
                            }
                        }
                    ],
                    "this_month": [
                        {
                            "$match": {
                                "orderDate": {"$gte": month_start, "$lte": month_end},
                                "status": "delivered"
                            }
                        },
                        {
                            "$group": {
                                "_id": None,
                                "revenue": {"$sum": "$total"},
                                "orders": {"$sum": 1}
                            }
                        }
                    ],
                    "prev_month": [
                        {
                            "$match": {
                                "orderDate": {"$gte": prev_month_start, "$lte": prev_month_end},
                                "status": "delivered"
                            }
                        },
                        {
                            "$group": {
                                "_id": None,
                                "revenue": {"$sum": "$total"},
                                "orders": {"$sum": 1}
                            }
                        }
                    ],
                    "this_year": [
                        {
                            "$match": {
                                "orderDate": {"$gte": year_start, "$lte": year_end},
                                "status": "delivered"
                            }
                        },
                        {
                            "$group": {
                                "_id": None,
                                "revenue": {"$sum": "$total"},
                                "orders": {"$sum": 1}
                            }
                        }
                    ],
                    "top_products": [
                        {
                            "$match": {
                                "status": "delivered"
                            }
                        },
                        {"$unwind": "$items"},
                        {
                            "$group": {
                                "_id": {
                                    "productId": "$items.productId",
                                    "productName": "$items.productName"
                                },
                                "total_revenue": {"$sum": {"$multiply": ["$items.subtotal", 1]}},
                                "quantity_sold": {"$sum": "$items.quantity"}
                            }
                        },
                        {"$sort": {"total_revenue": -1}},
                        {"$limit": 5}
                    ]
                }
            }
        ]
        
        result = list(orders_collection.aggregate(pipeline))
        
        if not result:
            return {
                "success": False,
                "message": "No revenue data available"
            }, 404
            
        data = result[0]
        
        # Process today data
        today_data = data['today'][0] if data['today'] else {"revenue": 0, "orders": 0}
        
        # Process this month data
        this_month_data = data['this_month'][0] if data['this_month'] else {"revenue": 0, "orders": 0}
        
        # Process previous month data
        prev_month_data = data['prev_month'][0] if data['prev_month'] else {"revenue": 0, "orders": 0}
        
        # Process this year data
        this_year_data = data['this_year'][0] if data['this_year'] else {"revenue": 0, "orders": 0}
        
        # Calculate month-over-month growth
        prev_month_revenue = prev_month_data.get('revenue', 0)
        this_month_revenue = this_month_data.get('revenue', 0)
        
        if prev_month_revenue > 0:
            mom_growth = ((this_month_revenue - prev_month_revenue) / prev_month_revenue) * 100
        else:
            mom_growth = 100 if this_month_revenue > 0 else 0
            
        # Format top products
        top_products = []
        for product in data['top_products']:
            top_products.append({
                "productId": object_id_to_str(product['_id']['productId']),
                "productName": product['_id']['productName'],
                "total_revenue": product['total_revenue'],
                "quantity_sold": product['quantity_sold']
            })
            
        summary = {
            "today": {
                "revenue": today_data.get('revenue', 0),
                "orders": today_data.get('orders', 0)
            },
            "this_month": {
                "revenue": this_month_data.get('revenue', 0),
                "orders": this_month_data.get('orders', 0),
                "avg_order_value": this_month_data.get('revenue', 0) / this_month_data.get('orders', 1) if this_month_data.get('orders', 0) > 0 else 0
            },
            "prev_month": {
                "revenue": prev_month_data.get('revenue', 0),
                "orders": prev_month_data.get('orders', 0)
            },
            "this_year": {
                "revenue": this_year_data.get('revenue', 0),
                "orders": this_year_data.get('orders', 0),
                "avg_order_value": this_year_data.get('revenue', 0) / this_year_data.get('orders', 1) if this_year_data.get('orders', 0) > 0 else 0
            },
            "growth": {
                "month_over_month": round(mom_growth, 2),
                "month_name": calendar.month_name[now.month]
            },
            "top_products": top_products
        }
        
        return {
            "success": True,
            "message": "Revenue summary",
            "data": summary
        }, 200

@revenue_ns.route('/by-product')
class ProductRevenue(Resource):
    @revenue_ns.doc('get_product_revenue')
    @revenue_ns.expect(period_parser)
    @revenue_ns.response(200, 'Success', revenue_response_model)
    def get(self):
        """Get revenue statistics by product"""
        args = period_parser.parse_args()
        period = args.get('period', 'monthly')
        
        now = datetime.now()
        
        # Determine date range based on period
        if period == 'yearly':
            year = args.get('year')
            # Ensure year has a default value if not provided
            if year is None:
                year = now.year
            start_date = datetime(year, 1, 1)
            end_date = datetime(year, 12, 31, 23, 59, 59)
        elif period == 'monthly':
            # Ensure both year and month have default values if not provided
            year = args.get('year')
            month = args.get('month')
            
            if year is None:
                year = now.year
            if month is None:
                month = now.month
                
            start_date = datetime(year, month, 1)
            if month == 12:
                end_date = datetime(year + 1, 1, 1) - timedelta(seconds=1)
            else:
                end_date = datetime(year, month + 1, 1) - timedelta(seconds=1)
        elif period == 'custom':
            try:
                start_date_str = args.get('start_date')
                end_date_str = args.get('end_date')
                
                if not start_date_str or not end_date_str:
                    return {
                        "success": False,
                        "message": "Both start_date and end_date are required for custom period"
                    }, 400
                    
                start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
                end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
                end_date = datetime.combine(end_date.date(), datetime.max.time())  # Set to end of day
            except ValueError:
                return {
                    "success": False,
                    "message": "Invalid date format. Use YYYY-MM-DD"
                }, 400
        else:
            # Default to last 30 days
            end_date = now
            start_date = end_date - timedelta(days=30)
            
        # Create pipeline to get revenue by product
        pipeline = [
            {
                "$match": {
                    "orderDate": {"$gte": start_date, "$lte": end_date},
                    "status": "delivered"
                }
            },
            {"$unwind": "$items"},
            {
                "$group": {
                    "_id": {
                        "productId": "$items.productId",
                        "productName": "$items.productName"
                    },
                    "total_revenue": {"$sum": "$items.subtotal"},
                    "quantity_sold": {"$sum": "$items.quantity"}
                }
            },
            {"$sort": {"total_revenue": -1}}
        ]
        
        result = list(orders_collection.aggregate(pipeline))
        
        # Format response
        response_data = []
        for item in result:
            response_data.append({
                "productId": object_id_to_str(item['_id']['productId']),
                "productName": item['_id']['productName'],
                "total_revenue": item['total_revenue'],
                "quantity_sold": item['quantity_sold'],
                "avg_price": item['total_revenue'] / item['quantity_sold'] if item['quantity_sold'] > 0 else 0
            })
            
        return {
            "success": True,
            "message": f"Product revenue statistics for {period} period",
            "data": response_data
        }, 200 
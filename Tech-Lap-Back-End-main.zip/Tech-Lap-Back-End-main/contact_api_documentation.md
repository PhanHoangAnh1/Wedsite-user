# Contact Form API Documentation

This document outlines the Contact Form API for Tech-Lap backend system. This API allows users to submit contact form messages through a standardized endpoint.

## Base URL

```
/api/contact
```

## Authentication

Currently, this API does not require authentication but will be secured in future updates.

## Response Format

All API responses follow this standard format:

```json
{
  "success": true|false,
  "message": "Response message",
  "data": [] | {}
}
```

## Available Endpoints

### 1. Submit Contact Message

Submit a message through the contact form.

**Endpoint:** `POST /api/contact`

**Request Body:**

```json
{
  "name": "String (required)",
  "email": "String (required)",
  "phone": "String (optional)",
  "subject": "String (required)",
  "message": "String (required)"
}
```

**Success Response (200 OK):**

```json
{
  "success": true,
  "messageId": "unique-message-id",
  "message": "Tin nhắn của bạn đã được gửi thành công"
}
```

**Error Responses:**

Validation Error (400 Bad Request):

```json
{
  "success": false,
  "error": "validation_error",
  "fields": {
    "name": "Vui lòng nhập họ và tên",
    "email": "Email không hợp lệ"
  }
}
```

Rate Limit Exceeded (429 Too Many Requests):

```json
{
  "success": false,
  "error": "rate_limit_exceeded",
  "message": "Quá nhiều yêu cầu. Vui lòng thử lại sau."
}
```

Server Error (500 Internal Server Error):

```json
{
  "success": false,
  "error": "server_error",
  "message": "Đã xảy ra lỗi khi gửi tin nhắn. Vui lòng thử lại sau."
}
```

### 2. Get All Contact Messages

Retrieve all contact messages with pagination and filtering options.

**Endpoint:** `GET /api/contact`

**Query Parameters:**

- `page` - Page number (default: 1)
- `limit` - Number of items per page (default: 10)
- `status` - Filter by status (e.g., "unread", "read")
- `search` - Search in name, email and subject fields

**Success Response (200 OK):**

```json
{
  "success": true,
  "data": [
    {
      "_id": "65c4f321b7e9a1234a567f8b",
      "name": "Nguyen Van A",
      "email": "nguyen.van.a@example.com",
      "phone": "0987654321",
      "subject": "Hỗ trợ đơn hàng",
      "message": "Tôi cần hỗ trợ về đơn hàng TS-20230315-123. Vui lòng liên hệ lại với tôi.",
      "message_id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
      "created_at": "2023-03-15T10:30:00.000Z",
      "status": "unread"
    },
    // More messages...
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 45,
    "total_pages": 5
  }
}
```

**Error Response (500 Internal Server Error):**

```json
{
  "success": false,
  "error": "server_error",
  "message": "Đã xảy ra lỗi khi lấy tin nhắn. Vui lòng thử lại sau."
}
```

### 3. Get Contact Message by ID

Retrieve a specific contact message by its ID. The message status will be automatically updated to "read" if it was previously "unread".

**Endpoint:** `GET /api/contact/:message_id`

**Success Response (200 OK):**

```json
{
  "success": true,
  "data": {
    "_id": "65c4f321b7e9a1234a567f8b",
    "name": "Nguyen Van A",
    "email": "nguyen.van.a@example.com",
    "phone": "0987654321",
    "subject": "Hỗ trợ đơn hàng",
    "message": "Tôi cần hỗ trợ về đơn hàng TS-20230315-123. Vui lòng liên hệ lại với tôi.",
    "message_id": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
    "created_at": "2023-03-15T10:30:00.000Z",
    "status": "read"
  }
}
```

**Error Responses:**

Not Found (404 Not Found):

```json
{
  "success": false,
  "error": "not_found",
  "message": "Không tìm thấy tin nhắn"
}
```

Server Error (500 Internal Server Error):

```json
{
  "success": false,
  "error": "server_error",
  "message": "Đã xảy ra lỗi khi lấy tin nhắn. Vui lòng thử lại sau."
}
```

### 4. Delete Contact Message

Delete a specific contact message by its ID.

**Endpoint:** `DELETE /api/contact/:message_id`

**Success Response (200 OK):**

```json
{
  "success": true,
  "message": "Tin nhắn đã được xóa thành công"
}
```

**Error Responses:**

Not Found (404 Not Found):

```json
{
  "success": false,
  "error": "not_found",
  "message": "Không tìm thấy tin nhắn"
}
```

Server Error (500 Internal Server Error):

```json
{
  "success": false,
  "error": "server_error",
  "message": "Đã xảy ra lỗi khi xóa tin nhắn. Vui lòng thử lại sau."
}
```

## Rate Limiting

- 5 submissions per IP address per hour
- Returns status code 429 if exceeded

## Security Considerations

- Input validation and sanitization is applied to all fields
- Rate limiting to prevent abuse
- CSRF protection is enabled via Flask-RESTx
- All fields are validated before processing

## Data Storage

Contact messages are stored in MongoDB with the following structure:

```json
{
  "_id": ObjectId,
  "name": "Customer Name",
  "email": "customer@example.com",
  "phone": "0123456789",
  "subject": "Subject line",
  "message": "Message content",
  "message_id": "unique-uuid",
  "created_at": ISODate("2023-03-15T10:30:00Z"),
  "status": "unread"
}
```

## Example Usage

### Example: Submit a Contact Message

**Request:**

```
POST /api/contact
Content-Type: application/json

{
  "name": "Nguyen Van A",
  "email": "nguyen.van.a@example.com",
  "phone": "0987654321",
  "subject": "Hỗ trợ đơn hàng",
  "message": "Tôi cần hỗ trợ về đơn hàng TS-20230315-123. Vui lòng liên hệ lại với tôi."
}
```

**Response:**

```json
{
  "success": true,
  "messageId": "f47ac10b-58cc-4372-a567-0e02b2c3d479",
  "message": "Tin nhắn của bạn đã được gửi thành công"
}
``` 
# Order API Documentation

This document describes the endpoints for managing orders in the system.

## Collection Schema: Orders

```javascript
{
  _id: ObjectId,
  orderNumber: String, // TS-YYYYMMDD-XXX
  customer: {
    fullName: String,
    phone: String,
    email: String
  },
  shippingAddress: {
    province: String,
    district: String,
    ward: String,
    streetAddress: String
  },
  items: [
    {
      productId: ObjectId,
      productName: String,
      basePrice: Number,
      
      // Variant selection (configuration)
      variantName: String,          // e.g., "APPLE M3"
      variantSpecs: {
        cpu: String,
        ram: String,
        storage: String,
        display: String,
        gpu: String,
        battery: String,
        os: String,
        ports: [String]
      },
      variantPrice: Number,         // Price specific to variant
      variantDiscountPercent: Number,
      
      // Color selection
      colorName: String,            // e.g., "Silver", "Black"
      colorCode: String,            // e.g., "#cfc9c9"
      colorPriceAdjustment: Number, // Additional cost for this color
      colorDiscountAdjustment: Number,
      
      quantity: Number,
      
      // Price calculations
      unitPrice: Number,            // Final unit price after variant and color
      discountedPrice: Number,      // Price after discount
      subtotal: Number,             // discountedPrice * quantity
      
      // Product image for order reference
      thumbnailUrl: String
    }
  ],
  payment: {
    method: String,                 // "COD"
    status: String                  // "pending", "paid"
  },
  productInfo: [                    // Copy of product_info for order record
    {
      title: String,
      content: String
    }
  ],
  subtotal: Number,                 // Sum of all item subtotals
  discountTotal: Number,            // Total discount amount
  shippingFee: Number,
  total: Number,                    // subtotal + shippingFee
  status: String,                   // "pending", "processing", "shipped", "delivered", "cancelled"
  orderDate: Date,
  updatedAt: Date
}
```

## Endpoints

### 1. Create Order

Creates a new order in the system.

**URL**: `/api/orders`

**Method**: `POST`

**Auth required**: No

**Request Body**:

```json
{
  "customer": {
    "fullName": "Nguyễn Văn A",
    "phone": "0901234567",
    "email": "nguyenvana@example.com"
  },
  "shippingAddress": {
    "province": "Hồ Chí Minh",
    "district": "Quận 1",
    "ward": "Phường Bến Nghé",
    "streetAddress": "123 Nguyễn Huệ"
  },
  "items": [
    {
      "productId": "67deaf2d7457268626f9e0eb",
      "quantity": 1,
      "variantName": "APPLE M3",
      "colorName": "Silver"
    }
  ],
  "payment": {
    "method": "COD"
  }
}
```

#### Success Response

**Code**: `201 CREATED`

**Content example**:

```json
{
  "success": true,
  "message": "Order created successfully",
  "data": {
    "orderId": "60d21b4667d0d8992e610c85",
    "orderNumber": "TS-20230724-001",
    "items": [
      {
        "productName": "MacBook Pro 16",
        "variantName": "APPLE M3",
        "colorName": "Silver",
        "quantity": 1,
        "unitPrice": 75170000,
        "discountedPrice": 71411500,
        "subtotal": 71411500
      }
    ],
    "subtotal": 71411500,
    "shippingFee": 0,
    "total": 71411500,
    "status": "pending"
  },
  "warnings": [
    "Requested variant 'Standard' not available. Using 'APPLE M3' instead."
  ]
}
```

#### Error Response

**Condition**: If the request is invalid or validation fails.

**Code**: `400 BAD REQUEST`

**Content example**:

```json
{
  "success": false,
  "message": "Failed to create order",
  "errors": [
    "Product not found",
    "Requested variant not available for product MacBook Pro 16",
    "Requested color not available for product MacBook Pro 16"
  ]
}
```

### 2. List Orders

Retrieves a list of orders with pagination and filtering options.

**URL**: `/api/orders`

**Method**: `GET`

**Auth required**: No

**Query Parameters**:

- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10, max: 100)
- `status` (optional): Filter by order status ('pending', 'processing', 'shipped', 'delivered', 'cancelled')
- `customer_email` (optional): Filter by customer email
- `customer_phone` (optional): Filter by customer phone
- `date_from` (optional): Filter by order date (ISO format)
- `date_to` (optional): Filter by order date (ISO format)
- `sort_by` (optional): Field to sort by (default: 'orderDate')
- `sort_order` (optional): Sort order ('asc' or 'desc', default: 'desc')

#### Success Response

**Code**: `200 OK`

**Content example**:

```json
{
  "success": true,
  "message": "Orders retrieved successfully",
  "data": {
    "orders": [
      {
        "_id": "60d21b4667d0d8992e610c85",
        "orderNumber": "TS-20230724-001",
        "customer": {
          "fullName": "Nguyễn Văn A",
          "phone": "0901234567",
          "email": "nguyenvana@example.com"
        },
        "status": "pending",
        "total": 71411500,
        "orderDate": "2023-07-24T10:30:00.000Z",
        "updatedAt": "2023-07-24T10:30:00.000Z",
        "items": [
          {
            "productId": "67deaf2d7457268626f9e0eb",
            "productName": "MacBook Pro 16",
            "variantName": "APPLE M3",
            "colorName": "Silver",
            "quantity": 1,
            "subtotal": 71411500
          }
        ]
      }
    ],
    "pagination": {
      "total": 1,
      "page": 1,
      "limit": 10,
      "pages": 1,
      "has_next": false,
      "has_prev": false
    }
  }
}
```

### 3. Get Order Details

Retrieves detailed information about a specific order.

**URL**: `/api/orders/:order_id`

**Method**: `GET`

**Auth required**: No

**URL Parameters**:

- `order_id`: The ID or order number of the order

#### Success Response

**Code**: `200 OK`

**Content example**:

```json
{
  "success": true,
  "message": "Order retrieved successfully",
  "data": {
    "_id": "60d21b4667d0d8992e610c85",
    "orderNumber": "TS-20230724-001",
    "customer": {
      "fullName": "Nguyễn Văn A",
      "phone": "0901234567",
      "email": "nguyenvana@example.com"
    },
    "shippingAddress": {
      "province": "Hồ Chí Minh",
      "district": "Quận 1",
      "ward": "Phường Bến Nghé",
      "streetAddress": "123 Nguyễn Huệ"
    },
    "items": [
      {
        "productId": "67deaf2d7457268626f9e0eb",
        "productName": "MacBook Pro 16",
        "basePrice": 58000000,
        "variantName": "APPLE M3",
        "variantSpecs": {
          "cpu": "M3 INTEL",
          "ram": "64GB",
          "storage": "2TB",
          "display": "17.0 ICNH",
          "gpu": "OLED",
          "battery": "1000KW",
          "os": "MAC M3",
          "ports": ["USB-C", "HDMI"]
        },
        "variantPrice": 75000000,
        "variantDiscountPercent": 5,
        "colorName": "Silver",
        "colorCode": "#cfc9c9",
        "colorPriceAdjustment": 170000,
        "colorDiscountAdjustment": 0,
        "quantity": 1,
        "unitPrice": 75170000,
        "discountedPrice": 71411500,
        "subtotal": 71411500,
        "thumbnailUrl": "67deaf2d7457268626f9e0ca"
      }
    ],
    "payment": {
      "method": "COD",
      "status": "pending"
    },
    "productInfo": [
      {
        "title": "Bảo hành",
        "content": "bảo hành trong vòng 24 tháng"
      },
      {
        "title": "Free ship",
        "content": "miễn phí vẫn chuyện ngoại thành và nội thành"
      }
    ],
    "subtotal": 71411500,
    "discountTotal": 3758500,
    "shippingFee": 0,
    "total": 71411500,
    "status": "pending",
    "orderDate": "2023-07-24T10:30:00.000Z",
    "updatedAt": "2023-07-24T10:30:00.000Z"
  }
}
```

#### Error Response

**Condition**: If the order is not found.

**Code**: `404 NOT FOUND`

**Content example**:

```json
{
  "success": false,
  "message": "Order not found",
  "errors": ["No order with ID or order number: 60d21b4667d0d8992e610c85"]
}
```

### 4. Update Order Status

Updates the status of an existing order.

**URL**: `/api/orders/:order_id`

**Method**: `PATCH`

**Auth required**: No

**URL Parameters**:

- `order_id`: The ID or order number of the order

**Request Body**:

```json
{
  "status": "processing"
}
```

Valid status values: `pending`, `processing`, `shipped`, `delivered`, `cancelled`

#### Success Response

**Code**: `200 OK`

**Content example**:

```json
{
  "success": true,
  "message": "Order status updated to 'processing' successfully",
  "data": {
    "_id": "60d21b4667d0d8992e610c85",
    "orderNumber": "TS-20230724-001",
    "status": "processing",
    "updatedAt": "2023-07-25T15:45:30.000Z",
    // Other order data...
  }
}
```

#### Error Response

**Condition**: If the request is invalid.

**Code**: `400 BAD REQUEST`

**Content example**:

```json
{
  "success": false,
  "message": "Invalid status",
  "errors": ["Status must be one of: pending, processing, shipped, delivered, cancelled"]
}
```

### 5. Cancel Order (Soft Delete)

Cancels an order by setting its status to 'cancelled'.

**URL**: `/api/orders/:order_id`

**Method**: `DELETE`

**Auth required**: No

**URL Parameters**:

- `order_id`: The ID or order number of the order

#### Success Response

**Code**: `200 OK`

**Content example**:

```json
{
  "success": true,
  "message": "Order cancelled successfully"
}
```

#### Error Response

**Condition**: If the order is not found.

**Code**: `404 NOT FOUND`

**Content example**:

```json
{
  "success": false,
  "message": "Order not found",
  "errors": ["No order with ID or order number: 60d21b4667d0d8992e610c85"]
}
```

### 6. Get Customer Orders by Email

Retrieves all orders for a specific customer identified by email.

**URL**: `/api/orders/by-customer/:customer_email`

**Method**: `GET`

**Auth required**: No

**URL Parameters**:

- `customer_email`: The email address of the customer

**Query Parameters**:

- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10, max: 100)
- `status` (optional): Filter by order status ('pending', 'processing', 'shipped', 'delivered', 'cancelled')

#### Success Response

**Code**: `200 OK`

**Content example**: Same format as the List Orders endpoint

### 7. Get Customer Orders by Phone

Retrieves all orders for a specific customer identified by phone number.

**URL**: `/api/orders/by-phone/:customer_phone`

**Method**: `GET`

**Auth required**: No

**URL Parameters**:

- `customer_phone`: The phone number of the customer

**Query Parameters**:

- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10, max: 100)
- `status` (optional): Filter by order status ('pending', 'processing', 'shipped', 'delivered', 'cancelled')

#### Success Response

**Code**: `200 OK`

**Content example**: Same format as the List Orders endpoint

### 8. Get Order Statistics

Retrieves summary statistics about orders.

**URL**: `/api/orders/statistics`

**Method**: `GET`

**Auth required**: No

#### Success Response

**Code**: `200 OK`

**Content example**:

```json
{
  "success": true,
  "message": "Order statistics retrieved successfully",
  "data": {
    "total_orders": 150,
    "orders_by_status": {
      "pending": 25,
      "processing": 35,
      "shipped": 40,
      "delivered": 45,
      "cancelled": 5
    },
    "total_sales": 1275000000,
    "recent_orders": 30
  }
}
```

## Notes

1. The API automatically sets quantity to 1 if an invalid (zero or negative) quantity is provided.
2. The final price calculation includes:
   - Base product price (from product.price)
   - Variant price (additional cost for the specific variant)
   - Color price adjustment (additional cost for the specific color)
   - Discounts from both variant and color
3. All product information needed for the order is stored with the order at creation time, including:
   - Product details
   - Variant specifications
   - Color information
   - Pricing details
4. Shipping is currently set to free (0 VND) for all orders.
5. When a variant or color is not found, the system will automatically use the first available one and include a warning in the response.
6. Orders can be looked up by either their MongoDB ObjectId or their unique order number (TS-YYYYMMDD-XXX format).
7. Order cancellation is implemented as a soft delete (status change to 'cancelled') rather than removing the record from the database. 
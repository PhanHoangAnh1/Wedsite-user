[{
  "_id": {
    "$oid": "67ddfa2c3c20160fc68f334f"
  },
  "name": "Sản phẩm mới",
  "brand": "Dell",
  "model": "XPS 15 9530",
  "price": "1000000",
  "discount_percent": "0",
  "stock_quantity": "10",
  "short_description": "25252",
  "specs": {
    "cpu": "25252",
    "ram": "2525",
    "storage": "2525",
    "display": "2525",
    "gpu": "2525",
    "battery": "2525",
    "os": "2525",
    "ports": [
      "25252"
    ]
  },
  "highlights": [
    "[\"25252\"]"
  ],
  "product_info": [
    {
      "title": "2525",
      "content": "25252"
    }
  ],
  "thumbnail_filename": "text_ng_n_4__7_24.webp",
  "thumbnail_content_type": "image/webp",
  "video_filename_0": "3233367357187590234.mp4",
  "video_content_type_0": "video/mp4",
  "video_count": "1",
  "images": [],
  "videos": [
    "67ddfa2c3c20160fc68f3337"
  ],
  "thumbnail": "67ddfa2c3c20160fc68f3335",
  "created_at": {
    "$date": "2025-03-21T23:45:48.042Z"
  },
  "updated_at": {
    "$date": "2025-03-21T23:45:48.042Z"
  },
  "discount_price": 1000000
}]
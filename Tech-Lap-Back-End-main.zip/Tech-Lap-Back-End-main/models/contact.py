from datetime import datetime
from bson import ObjectId

class ContactMessage:
    """
    Model for storing contact form messages
    """
    def __init__(self, name, email, subject, message, phone=None):
        self.name = name
        self.email = email
        self.phone = phone
        self.subject = subject
        self.message = message
        self.created_at = datetime.utcnow()
        self.status = "unread"  # Default status

    @classmethod
    def from_dict(cls, data):
        """
        Create a contact message object from dictionary data
        """
        return cls(
            name=data.get('name'),
            email=data.get('email'),
            phone=data.get('phone'),
            subject=data.get('subject'),
            message=data.get('message')
        )

    def to_dict(self):
        """
        Convert contact message to dictionary
        """
        return {
            "name": self.name,
            "email": self.email,
            "phone": self.phone,
            "subject": self.subject,
            "message": self.message,
            "created_at": self.created_at,
            "status": self.status
        }

    def validate(self):
        """
        Validate contact message data
        """
        errors = {}
        
        # Validate name
        if not self.name or not self.name.strip():
            errors['name'] = "Vui lòng nhập họ và tên"
        
        # Validate email
        if not self.email or "@" not in self.email:
            errors['email'] = "Email không hợp lệ"
        
        # Validate subject
        if not self.subject or not self.subject.strip():
            errors['subject'] = "Vui lòng nhập tiêu đề"
        
        # Validate message
        if not self.message or not self.message.strip():
            errors['message'] = "Vui lòng nhập nội dung tin nhắn"
            
        return errors 
# Tech-Lap Backend API

Hệ thống Back-End API cho website Tech-Lap - Cửa hàng bán thiết bị công nghệ.

## Tổng quan

Tech-Lap Back-End API cung cấp các endpoint để quản lý sản phẩm, danh mục, đơn hàng và báo cáo doanh thu cho website bán hàng thiết bị công nghệ.

## Công nghệ sử dụng

- **Python 3.9+**
- **Flask & Flask-RESTx**: Framework xây dựng API với hỗ trợ Swagger UI
- **MongoDB**: Cơ sở dữ liệu NoSQL
- **PyMongo**: Thư viện Python để làm việc với MongoDB
- **Flask-CORS**: Hỗ trợ CORS (Cross-Origin Resource Sharing)

## Cài đặt

1. Clone repository

```bash
git clone https://github.com/yourusername/Tech-Lap-Back-End.git
cd Tech-Lap-Back-End
```

2. Cài đặt các thư viện phụ thuộc

```bash
pip install -r requirements.txt
```

3. Thiết lập biến môi trường

Tạo file `.env` tại thư mục gốc với nội dung:

```
MONGODB_URI=mongodb://localhost:27017/
DB_NAME=tech_lap
```

4. Chạy ứng dụng

```bash
python app.py
```

Ứng dụng sẽ chạy tại http://localhost:5000

## Tài liệu API

Các API của hệ thống được phân chia theo chức năng và có tài liệu chi tiết:

- **Swagger UI**: Truy cập `/api/docs` để xem tài liệu Swagger tương tác
- **API Documentation**:
  - [Product API](/product_api_documentation.md)
  - [Category API](/category_api_documentation.md)
  - [Order API](/order_api_documentation.md)
  - [Product Search API](/product_search_api_documentation.md)
  - [Revenue API](/revenue_api_documentation.md)

## Cấu trúc dự án

```
Tech-Lap-Back-End/
├── app.py                  # Entry point của ứng dụng
├── database.py             # Kết nối và cấu hình MongoDB
├── requirements.txt        # Danh sách thư viện phụ thuộc
├── .env                    # Biến môi trường (không ghi vào git)
├── models/                 # Model định nghĩa cấu trúc dữ liệu
│   ├── __init__.py
│   ├── product.py
│   ├── category.py
│   └── order.py
├── routes/                 # Định nghĩa các route API
│   ├── product_routes.py
│   ├── category_routes.py
│   ├── order_routes.py
│   ├── product_search.py
│   └── revenue_routes.py
├── schemas/                # Schema để validate dữ liệu
├── utils/                  # Các tiện ích
└── *_api_documentation.md  # Tài liệu API
```

## Các API chính

### 1. Product API (`/api/products`)

API quản lý sản phẩm, bao gồm các thao tác CRUD (Create, Read, Update, Delete) cho sản phẩm.

### 2. Category API (`/api/categories`) 

API quản lý danh mục sản phẩm.

### 3. Order API (`/api/orders`)

API quản lý đơn hàng, cho phép tạo đơn hàng mới, cập nhật trạng thái, và truy vấn đơn hàng.

### 4. Product Search API (`/api/product-search`)

API tìm kiếm sản phẩm với nhiều bộ lọc và sắp xếp.

### 5. Revenue API (`/api/revenue`)

API báo cáo và thống kê doanh thu:

- `/api/revenue/statistics`: Thống kê doanh thu theo thời gian (ngày, tuần, tháng, năm)
- `/api/revenue/summary`: Tóm tắt doanh thu, so sánh tăng trưởng và sản phẩm bán chạy
- `/api/revenue/by-product`: Thống kê doanh thu theo sản phẩm

## Chức năng báo cáo doanh thu

Hệ thống cung cấp các API báo cáo doanh thu đa dạng:

### Thống kê doanh thu theo thời gian

- Thống kê theo ngày
- Thống kê theo tuần  
- Thống kê theo tháng
- Thống kê theo năm
- Thống kê theo khoảng thời gian tùy chỉnh

### Tóm tắt doanh thu

- Doanh thu hôm nay
- Doanh thu tháng hiện tại và so sánh với tháng trước
- Doanh thu năm hiện tại
- Tỷ lệ tăng trưởng so với tháng trước
- Top sản phẩm bán chạy nhất

### Phân tích doanh thu theo sản phẩm

- Doanh thu từng sản phẩm
- Số lượng bán ra
- Giá trung bình

## Đóng góp

Vui lòng gửi pull request để cải thiện mã nguồn. Đối với các thay đổi lớn, vui lòng mở issue trước để thảo luận.

## Giấy phép

Dự án được phân phối dưới giấy phép MIT. Xem file `LICENSE` để biết thêm chi tiết.

export const environment = {
  production: true,
  apiUrl: '/api' // For production, use relative URL or full URL to your API server
}; 
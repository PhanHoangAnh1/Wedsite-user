export const environment = {
  production: false,
  apiUrl: '' // Empty to use Angular proxy in development
}; 